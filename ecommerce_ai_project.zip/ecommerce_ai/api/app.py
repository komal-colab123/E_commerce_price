# api/app.py
# ─────────────────────────────────────────────────────────
# Flask REST API — exposes pipeline results as JSON endpoints.
#
# Run:
#     python api/app.py
#
# Endpoints:
#     GET  /                        Health check
#     GET  /trending                Top products by popularity score
#     GET  /trending?top=10         Limit results
#     GET  /trending?category=Audio Filter by category
#     GET  /trending?platform=Amazon Filter by platform
#     GET  /price-comparison        Cross-platform price matches
#     GET  /price-comparison?brand=Sony Filter by brand
#     GET  /platforms               Platform-level summary stats
#     GET  /categories              Category-level summary stats
#     POST /analyse                 Run pipeline on uploaded CSV data
#
# n8n Integration:
#     Use "HTTP Request" node → GET http://localhost:5000/trending
# ─────────────────────────────────────────────────────────

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from flask import Flask, jsonify, request
from flask_cors import CORS
import pandas as pd

from config import API_HOST, API_PORT, API_DEBUG
from main import run_pipeline

app = Flask(__name__)
CORS(app)   # Allow cross-origin requests (needed for n8n)

# ── Run pipeline once at startup ──────────────────────────
print("[API] Running pipeline on startup...")
_results = run_pipeline()
_df         = _results["df"]
_matches_df = _results["matches_df"]
_trend_df   = _results["trend_df"]
print("[API] Pipeline ready. Starting server...\n")


def _df_to_json(df: pd.DataFrame) -> list:
    """Convert DataFrame to JSON-safe list of dicts."""
    return df.where(pd.notnull(df), None).to_dict("records")


# ── Routes ────────────────────────────────────────────────

@app.route("/", methods=["GET"])
def health():
    return jsonify({
        "status": "ok",
        "message": "E-commerce AI Intelligence API is running",
        "total_products": len(_df),
        "platforms": _df["platform"].unique().tolist(),
        "endpoints": [
            "/trending",
            "/price-comparison",
            "/platforms",
            "/categories",
            "/analyse (POST)",
        ],
    })


@app.route("/trending", methods=["GET"])
def trending():
    """
    Returns top products ranked by popularity score.

    Query params:
        top       (int)    – number of products to return (default 20)
        category  (str)    – filter by category (e.g. Audio, Fashion)
        platform  (str)    – filter by platform (e.g. Amazon)
        min_score (float)  – minimum popularity score (0.0–1.0)
    """
    df = _df.copy()

    # Filters
    category = request.args.get("category")
    platform  = request.args.get("platform")
    min_score = request.args.get("min_score", type=float)
    top       = request.args.get("top", default=20, type=int)

    if category:
        df = df[df["category"].str.lower() == category.lower()]
    if platform:
        df = df[df["platform"].str.lower() == platform.lower()]
    if min_score is not None:
        df = df[df["popularity_score"] >= min_score]

    result = df.nlargest(top, "popularity_score")

    cols = [c for c in [
        "product_name", "brand", "category", "platform",
        "price", "rating", "review_count",
        "popularity_score", "popularity_tier",
        "trend_score", "trend_label",
    ] if c in result.columns]

    result = result[cols]
    result.insert(0, "rank", range(1, len(result) + 1))

    return jsonify({
        "status": "success",
        "count":  len(result),
        "filters": {
            "category": category, "platform": platform,
            "min_score": min_score, "top": top,
        },
        "data": _df_to_json(result),
    })


@app.route("/price-comparison", methods=["GET"])
def price_comparison():
    """
    Returns cross-platform price matches.

    Query params:
        brand     (str)   – filter by brand
        category  (str)   – filter by category
        min_saving (float) – minimum saving percentage
    """
    df = _matches_df.copy()

    brand      = request.args.get("brand")
    category   = request.args.get("category")
    min_saving = request.args.get("min_saving", type=float)

    if brand:
        df = df[df["brand"].str.lower() == brand.lower()]
    if category:
        df = df[df["category"].str.lower() == category.lower()]
    if min_saving is not None:
        df = df[df["saving_pct"] >= min_saving]

    df = df.sort_values("saving_pct", ascending=False)

    return jsonify({
        "status": "success",
        "count":  len(df),
        "data": _df_to_json(df),
    })


@app.route("/platforms", methods=["GET"])
def platforms():
    """Platform-level summary statistics."""
    stats = (
        _df.groupby("platform")
        .agg(
            total_products = ("product_name", "count"),
            avg_price      = ("price",        "mean"),
            avg_rating     = ("rating",       "mean"),
            avg_popularity = ("popularity_score", "mean"),
            categories     = ("category",     "nunique"),
        )
        .round(2)
        .reset_index()
    )
    return jsonify({"status": "success", "data": _df_to_json(stats)})


@app.route("/categories", methods=["GET"])
def categories():
    """Category-level summary statistics."""
    stats = (
        _df.groupby("category")
        .agg(
            total_products = ("product_name", "count"),
            avg_price      = ("price",        "mean"),
            avg_rating     = ("rating",       "mean"),
            avg_popularity = ("popularity_score", "mean"),
            platforms      = ("platform",     "nunique"),
        )
        .round(2)
        .sort_values("total_products", ascending=False)
        .reset_index()
    )
    return jsonify({"status": "success", "data": _df_to_json(stats)})


@app.route("/analyse", methods=["POST"])
def analyse():
    """
    Accept a JSON payload of product records and run the pipeline.

    POST body (JSON):
    [
        {"product_name": "...", "price": 999, "rating": 4.2,
         "review_count": 5000, "platform": "Amazon"},
        ...
    ]
    """
    try:
        data = request.get_json(force=True)
        if not data:
            return jsonify({"status": "error", "message": "No JSON body"}), 400

        df_input = pd.DataFrame(data)

        from utils.cleaner  import clean_dataframe
        from utils.scorer   import compute_popularity
        from utils.matcher  import match_products

        df_clean  = clean_dataframe(df_input)
        df_scored = compute_popularity(df_clean)
        matches   = match_products(df_scored)

        top10 = df_scored.nlargest(10, "popularity_score")
        cols = [c for c in [
            "product_name", "brand", "category", "platform",
            "price", "rating", "review_count",
            "popularity_score", "popularity_tier",
        ] if c in top10.columns]
        top10 = top10[cols]
        top10.insert(0, "rank", range(1, len(top10) + 1))

        return jsonify({
            "status": "success",
            "total_input": len(df_input),
            "trending": _df_to_json(top10),
            "price_comparison": _df_to_json(matches),
        })

    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500


# ── Server ────────────────────────────────────────────────
if __name__ == "__main__":
    print(f"[API] Server starting at http://{API_HOST}:{API_PORT}")
    app.run(host=API_HOST, port=API_PORT, debug=API_DEBUG)
