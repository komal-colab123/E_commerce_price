# tests/test_pipeline.py
# ─────────────────────────────────────────────────────────
# Basic unit tests for all pipeline stages.
#
# Run:
#     python -m pytest tests/test_pipeline.py -v
#     # or without pytest:
#     python tests/test_pipeline.py
# ─────────────────────────────────────────────────────────

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pandas as pd
import numpy as np


# ── Sample Data ───────────────────────────────────────────

def make_sample_df():
    return pd.DataFrame({
        "product_name": [
            "boAt Rockerz 450 Bluetooth Headphone",
            "boAt Rockerz 450 Wireless Headphones",
            "Sony WH-1000XM5 Noise Cancelling Headphones",
            "Lakme Absolute Matte Lipstick",
            "HP 15 Core i5 Laptop",
            "Nike Air Max 270 Running Shoes",
        ],
        "price":        [1499, 1399, 29990, 450, 54999, 8995],
        "rating":       [4.1, 4.0, 4.6, 4.3, 4.4, 4.5],
        "review_count": [85000, 62000, 12000, 54000, 18000, 7800],
        "platform":     ["Amazon", "Flipkart", "Amazon", "Amazon", "Amazon", "Amazon"],
    })


# ── Test: Cleaner ─────────────────────────────────────────

def test_clean_name():
    from utils.cleaner import clean_name
    assert clean_name("boAt Rockerz 450!!") == "boat rockerz 450"
    assert clean_name("Sony WH-1000XM5") == "sony wh 1000xm5"
    assert clean_name("") == ""
    assert clean_name(None) == ""
    print("[PASS] test_clean_name")


def test_extract_brand():
    from utils.cleaner import extract_brand
    assert extract_brand("boat rockerz 450") == "Boat"
    assert extract_brand("sony wh 1000xm5") == "Sony"
    assert extract_brand("") == "Unknown"
    print("[PASS] test_extract_brand")


def test_extract_category():
    from utils.cleaner import extract_category
    assert extract_category("Bluetooth Headphone") == "Audio"
    assert extract_category("Running Shoes Nike") == "Fashion"
    assert extract_category("Laptop Core i5") == "Computers"
    assert extract_category("Random Gadget XYZ") == "General"
    print("[PASS] test_extract_category")


def test_clean_dataframe():
    from utils.cleaner import clean_dataframe
    df = make_sample_df()
    result = clean_dataframe(df)

    assert "clean_name" in result.columns
    assert "brand" in result.columns
    assert "category" in result.columns
    assert "match_name" in result.columns
    assert len(result) == len(df)
    assert result["rating"].max() <= 5.0
    print("[PASS] test_clean_dataframe")


# ── Test: Scorer ──────────────────────────────────────────

def test_popularity_score():
    from utils.cleaner import clean_dataframe
    from utils.scorer import compute_popularity

    df = clean_dataframe(make_sample_df())
    result = compute_popularity(df)

    assert "popularity_score" in result.columns
    assert "popularity_tier" in result.columns
    assert result["popularity_score"].min() >= 0.0
    assert result["popularity_score"].max() <= 1.0

    # Sony has fewer reviews but very high rating;
    # boAt has far more reviews — either could be top, just check both are scored
    assert result["popularity_score"].notna().all()
    print("[PASS] test_popularity_score")


def test_trend_score():
    from utils.cleaner import clean_dataframe
    from utils.scorer import compute_trend

    df_now = clean_dataframe(pd.DataFrame({
        "product_name": ["Product A", "Product B"],
        "price": [100, 200],
        "rating": [4.0, 4.5],
        "review_count": [10000, 5000],
        "platform": ["Amazon", "Amazon"],
    }))

    df_old = clean_dataframe(pd.DataFrame({
        "product_name": ["Product A", "Product B"],
        "price": [120, 200],
        "rating": [4.0, 4.5],
        "review_count": [8000, 4000],
        "platform": ["Amazon", "Amazon"],
    }))

    result = compute_trend(df_now, df_old)
    assert "review_growth_pct" in result.columns
    assert "trend_score" in result.columns
    assert "trend_label" in result.columns
    # Product A grew from 8000 to 10000 = 25% growth
    row_a = result[result["clean_name"] == "product a"]
    assert abs(row_a["review_growth_pct"].values[0] - 25.0) < 0.1
    print("[PASS] test_trend_score")


# ── Test: Matcher ─────────────────────────────────────────

def test_product_matching():
    from utils.cleaner import clean_dataframe
    from utils.matcher import match_products

    # Use a richer dataset so TF-IDF has enough vocabulary
    df = clean_dataframe(pd.DataFrame({
        "product_name": [
            "boAt Rockerz 450 Bluetooth Headphone",
            "boAt Rockerz 450 Wireless Headphones",
            "Sony WH-1000XM5 Noise Cancelling Headphones",
            "Sony WH-1000XM5 Wireless Headphone",
            "Nike Air Max 270 Running Shoes",
            "Completely Different Unrelated Product",
        ],
        "price":        [1499, 1399, 29990, 28999, 8995, 999],
        "rating":       [4.1, 4.0, 4.6, 4.5, 4.5, 4.2],
        "review_count": [85000, 62000, 12000, 8500, 7800, 1000],
        "platform":     ["Amazon", "Flipkart", "Amazon", "Flipkart", "Amazon", "Myntra"],
    }))

    matches = match_products(df, threshold=0.60)
    assert len(matches) >= 1, "Should find at least one match for boAt Rockerz"
    assert "cheaper_on" in matches.columns
    assert "saving_pct" in matches.columns

    # The match should be between Amazon and Flipkart
    m = matches.iloc[0]
    platforms_in_match = {m["platform_a"], m["platform_b"]}
    assert "Amazon" in platforms_in_match
    assert "Flipkart" in platforms_in_match
    print("[PASS] test_product_matching")


def test_no_same_platform_matches():
    from utils.cleaner import clean_dataframe
    from utils.matcher import match_products

    # All same platform — should return no matches
    df = clean_dataframe(pd.DataFrame({
        "product_name": ["Product A Wireless", "Product A Bluetooth"],
        "price":        [999, 1099],
        "rating":       [4.0, 4.1],
        "review_count": [5000, 6000],
        "platform":     ["Amazon", "Amazon"],
    }))

    matches = match_products(df, threshold=0.70)
    assert len(matches) == 0, "Same-platform products should never match"
    print("[PASS] test_no_same_platform_matches")


# ── Test: Full Pipeline ───────────────────────────────────

def test_full_pipeline():
    from main import run_pipeline
    from config import SAMPLE_DATA_PATH

    if not os.path.exists(SAMPLE_DATA_PATH):
        print("[SKIP] test_full_pipeline — sample data not found")
        return

    results = run_pipeline(data_path=SAMPLE_DATA_PATH)

    assert "df" in results
    assert "matches_df" in results
    assert len(results["df"]) > 0
    assert "popularity_score" in results["df"].columns
    print("[PASS] test_full_pipeline")


# ── Runner ────────────────────────────────────────────────

if __name__ == "__main__":
    print("Running unit tests...\n")

    tests = [
        test_clean_name,
        test_extract_brand,
        test_extract_category,
        test_clean_dataframe,
        test_popularity_score,
        test_trend_score,
        test_product_matching,
        test_no_same_platform_matches,
        test_full_pipeline,
    ]

    passed = 0
    failed = 0

    for test in tests:
        try:
            test()
            passed += 1
        except AssertionError as e:
            print(f"[FAIL] {test.__name__}: {e}")
            failed += 1
        except Exception as e:
            print(f"[ERROR] {test.__name__}: {type(e).__name__}: {e}")
            failed += 1

    print(f"\n{'═'*40}")
    print(f"Results: {passed} passed, {failed} failed")
    print('═'*40)
