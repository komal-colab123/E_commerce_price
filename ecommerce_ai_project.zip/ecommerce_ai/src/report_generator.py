"""
Module: report_generator.py
Purpose: Compile analysis results into structured JSON and CSV reports.
"""

import json
import os
from datetime import datetime

import pandas as pd


# ── Helper ─────────────────────────────────────────────────────────────────────

def _safe_records(df: pd.DataFrame) -> list:
    """Convert DataFrame to list of dicts, handling NaN safely."""
    return json.loads(df.to_json(orient="records"))


# ── Main report builder ────────────────────────────────────────────────────────

def generate_full_report(
    df: pd.DataFrame,
    matches_df: pd.DataFrame,
    trending_df: pd.DataFrame,
    category_summary: pd.DataFrame,
    platform_summary: pd.DataFrame,
    output_dir: str = "../output",
    top_n: int = 15,
) -> dict:
    """
    Build and save the complete intelligence report.

    Returns a dict with all sections (also saved to JSON + CSV files).
    """
    os.makedirs(output_dir, exist_ok=True)
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # ── Section 1: Top trending products ──────────────────────────────────────
    trending_records = _safe_records(
        trending_df[["product_name", "brand", "category", "platform",
                     "price", "rating", "review_count",
                     "popularity_score", "trending_score"]].head(top_n)
    )

    # ── Section 2: Price comparison ───────────────────────────────────────────
    price_records = []
    if not matches_df.empty:
        price_records = _safe_records(
            matches_df[["brand", "category",
                         "product_a", "platform_a", "price_a",
                         "product_b", "platform_b", "price_b",
                         "similarity", "price_diff", "savings_pct",
                         "cheaper_on"]].head(top_n)
        )

    # ── Section 3: Best deals (cheapest per brand) ────────────────────────────
    best_deals = []
    if not matches_df.empty:
        all_options = []
        for _, row in matches_df.iterrows():
            all_options.extend([
                {"brand": row["brand"], "category": row["category"],
                 "product": row["product_a"], "platform": row["platform_a"],
                 "price": row["price_a"], "rating": row["rating_a"]},
                {"brand": row["brand"], "category": row["category"],
                 "product": row["product_b"], "platform": row["platform_b"],
                 "price": row["price_b"], "rating": row["rating_b"]},
            ])
        options_df = pd.DataFrame(all_options).drop_duplicates()
        best = (
            options_df.loc[options_df.groupby(["brand", "category"])["price"].idxmin()]
            .reset_index(drop=True)
        )
        best_deals = _safe_records(best)

    # ── Section 4: Category insights ──────────────────────────────────────────
    category_records = _safe_records(category_summary)

    # ── Section 5: Platform insights ──────────────────────────────────────────
    platform_records = _safe_records(platform_summary)

    # ── Section 6: Overall stats ──────────────────────────────────────────────
    overall = {
        "total_products_analysed": int(len(df)),
        "platforms_covered":       df["platform"].nunique(),
        "categories_found":        df["category"].nunique(),
        "brands_found":            df["brand"].nunique(),
        "cross_platform_matches":  int(len(matches_df)),
        "avg_price_inr":           round(float(df["price"].mean()), 2),
        "avg_rating":              round(float(df["rating"].mean()), 2),
        "total_reviews_indexed":   int(df["review_count"].sum()),
    }

    # ── Assemble full report ──────────────────────────────────────────────────
    report = {
        "report_title":     "AI-Powered E-commerce Trend & Product Intelligence",
        "generated_at":     timestamp,
        "overall_stats":    overall,
        "trending_products":   trending_records,
        "price_comparison":    price_records,
        "best_deals":          best_deals,
        "category_insights":   category_records,
        "platform_insights":   platform_records,
    }

    # ── Save JSON ─────────────────────────────────────────────────────────────
    json_path = os.path.join(output_dir, "intelligence_report.json")
    with open(json_path, "w") as f:
        json.dump(report, f, indent=2)
    print(f"[✓] JSON report saved: {json_path}")

    # ── Save CSV files ────────────────────────────────────────────────────────
    trending_df.head(top_n).to_csv(
        os.path.join(output_dir, "trending_products.csv"), index=False)
    print(f"[✓] Trending products CSV saved")

    if not matches_df.empty:
        matches_df.to_csv(
            os.path.join(output_dir, "price_comparison.csv"), index=False)
        print(f"[✓] Price comparison CSV saved")

    category_summary.to_csv(
        os.path.join(output_dir, "category_summary.csv"), index=False)
    print(f"[✓] Category summary CSV saved")

    platform_summary.to_csv(
        os.path.join(output_dir, "platform_summary.csv"), index=False)
    print(f"[✓] Platform summary CSV saved")

    df.to_csv(
        os.path.join(output_dir, "full_enriched_products.csv"), index=False)
    print(f"[✓] Full enriched product data saved")

    return report


# ── Pretty print to console ───────────────────────────────────────────────────

def print_summary(report: dict) -> None:
    """Print a human-readable summary to the console."""
    stats = report["overall_stats"]
    print("\n" + "="*65)
    print(f"  {report['report_title']}")
    print(f"  Generated: {report['generated_at']}")
    print("="*65)

    print(f"\n📊 Overall Stats")
    print(f"   Products analysed  : {stats['total_products_analysed']}")
    print(f"   Platforms covered  : {stats['platforms_covered']}")
    print(f"   Categories found   : {stats['categories_found']}")
    print(f"   Cross-platform hits: {stats['cross_platform_matches']}")
    print(f"   Avg price (₹)      : {stats['avg_price_inr']:,.2f}")
    print(f"   Total reviews      : {stats['total_reviews_indexed']:,}")

    print(f"\n🔥 Top 5 Trending Products")
    for i, p in enumerate(report["trending_products"][:5], 1):
        print(f"   {i}. {p['product_name'][:45]:<45} "
              f"[{p['platform']}]  ★{p['rating']}  "
              f"Score: {p['trending_score']:.3f}")

    if report["price_comparison"]:
        print(f"\n💰 Top 5 Price Comparison Opportunities")
        for p in report["price_comparison"][:5]:
            print(f"   {p['brand']} ({p['category']})")
            print(f"     {p['platform_a']}: ₹{p['price_a']:,.0f}  vs  "
                  f"{p['platform_b']}: ₹{p['price_b']:,.0f}  "
                  f"→ Save {p['savings_pct']:.1f}% on {p['cheaper_on']}")

    print(f"\n📦 Category Insights")
    for c in report["category_insights"]:
        print(f"   {c['category']:<12} {c['total_products']:>3} products  "
              f"Avg ₹{c['avg_price']:>8,.0f}  "
              f"Popularity: {c['avg_popularity']:.3f}")

    print("\n" + "="*65 + "\n")
