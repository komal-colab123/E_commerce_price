"""
Module: product_matcher.py
Purpose: Match the same product listed across different platforms using
         TF-IDF vectorisation + cosine similarity.
"""

import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


# ── Core matching logic ───────────────────────────────────────────────────────

def match_products(df: pd.DataFrame,
                   threshold: float = 0.72,
                   name_col: str = "clean_name") -> pd.DataFrame:
    """
    Find products that are likely the same item sold on different platforms.

    Algorithm:
        1. TF-IDF vectorise all clean product names (unigrams + bigrams).
        2. Compute pairwise cosine similarity.
        3. Keep pairs where:
               similarity >= threshold  AND  platforms differ.

    Parameters
    ----------
    df         : Cleaned product DataFrame (must have `clean_name`, `platform`,
                 `price`, `rating`, `review_count`).
    threshold  : Minimum cosine similarity to consider two names a match.
                 0.72 works well; raise to 0.85 for stricter matching.
    name_col   : Column containing normalised product names.

    Returns
    -------
    DataFrame with one row per matched pair, including price comparison.
    """
    if df.empty:
        return pd.DataFrame()

    # Build TF-IDF matrix
    vectorizer  = TfidfVectorizer(ngram_range=(1, 2), min_df=1)
    tfidf_matrix = vectorizer.fit_transform(df[name_col].fillna(""))

    # Pairwise cosine similarity (n × n matrix)
    sim_matrix = cosine_similarity(tfidf_matrix)

    matches = []
    n = len(df)

    for i in range(n):
        for j in range(i + 1, n):
            score = sim_matrix[i][j]
            if score < threshold:
                continue

            row_i = df.iloc[i]
            row_j = df.iloc[j]

            # Only match across different platforms
            if row_i["platform"] == row_j["platform"]:
                continue

            price_diff = abs(row_i["price"] - row_j["price"])
            cheaper_platform = (
                row_i["platform"] if row_i["price"] <= row_j["price"]
                else row_j["platform"]
            )
            savings_pct = (
                price_diff / max(row_i["price"], row_j["price"]) * 100
                if max(row_i["price"], row_j["price"]) > 0 else 0
            )

            matches.append({
                "product_a":        row_i["product_name"],
                "platform_a":       row_i["platform"],
                "price_a":          row_i["price"],
                "rating_a":         row_i["rating"],
                "reviews_a":        row_i["review_count"],

                "product_b":        row_j["product_name"],
                "platform_b":       row_j["platform"],
                "price_b":          row_j["price"],
                "rating_b":         row_j["rating"],
                "reviews_b":        row_j["review_count"],

                "similarity":       round(float(score), 3),
                "price_diff":       round(price_diff, 2),
                "savings_pct":      round(savings_pct, 1),
                "cheaper_on":       cheaper_platform,
                "category":         row_i.get("category", "General"),
                "brand":            row_i.get("brand", "Unknown"),
            })

    matches_df = pd.DataFrame(matches)
    if not matches_df.empty:
        matches_df = matches_df.sort_values("similarity", ascending=False).reset_index(drop=True)
    return matches_df


# ── Price comparison summary ──────────────────────────────────────────────────

def price_comparison_summary(matches_df: pd.DataFrame) -> pd.DataFrame:
    """
    For each matched product group, return the best price available
    across all platforms.
    """
    if matches_df.empty:
        return pd.DataFrame()

    rows = []
    for _, row in matches_df.iterrows():
        rows.append({
            "brand":           row["brand"],
            "category":        row["category"],
            "product":         row["product_a"],
            "platform":        row["platform_a"],
            "price":           row["price_a"],
            "rating":          row["rating_a"],
        })
        rows.append({
            "brand":           row["brand"],
            "category":        row["category"],
            "product":         row["product_b"],
            "platform":        row["platform_b"],
            "price":           row["price_b"],
            "rating":          row["rating_b"],
        })

    combined = pd.DataFrame(rows).drop_duplicates()

    # Best deal per brand+category group
    best = (
        combined.loc[combined.groupby(["brand", "category"])["price"].idxmin()]
        .rename(columns={"price": "best_price", "platform": "best_platform"})
        [["brand", "category", "best_price", "best_platform"]]
        .reset_index(drop=True)
    )
    return best


# ── Quick test ────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import sys
    sys.path.insert(0, ".")
    from data_cleaner import clean_dataframe
    from feature_engineering import build_features

    raw = pd.read_csv("../data/products.csv")
    df  = build_features(clean_dataframe(raw))

    matches = match_products(df)
    print(f"\nFound {len(matches)} cross-platform matches\n")
    print(matches[["product_a", "platform_a", "price_a",
                   "product_b", "platform_b", "price_b",
                   "similarity", "cheaper_on"]].head(10).to_string(index=False))

    print("\nBest deals by brand:")
    print(price_comparison_summary(matches).to_string(index=False))
