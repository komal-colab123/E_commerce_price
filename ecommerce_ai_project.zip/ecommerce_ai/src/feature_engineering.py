"""
Module: feature_engineering.py
Purpose: Compute popularity scores, trend scores, and derived features.
"""

import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler


# ── Popularity score ──────────────────────────────────────────────────────────

def compute_popularity_score(df: pd.DataFrame,
                              rating_weight: float = 0.5,
                              review_weight: float = 0.5) -> pd.DataFrame:
    """
    Popularity Score = (rating_weight × normalised_rating)
                     + (review_weight × normalised_log_reviews)

    Why log on review_count?
        A product with 500k reviews shouldn't dwarf one with 50k.
        log(1 + x) compresses the scale so both matter.

    Returns df with new columns:
        log_reviews, norm_rating, norm_reviews, popularity_score
    """
    df = df.copy()
    df["log_reviews"] = np.log1p(df["review_count"])

    scaler = MinMaxScaler()
    df[["norm_rating", "norm_reviews"]] = scaler.fit_transform(
        df[["rating", "log_reviews"]]
    )

    df["popularity_score"] = (
        rating_weight * df["norm_rating"] +
        review_weight * df["norm_reviews"]
    ).round(4)

    return df


# ── Trend score ───────────────────────────────────────────────────────────────

def compute_trend_score(df_new: pd.DataFrame,
                        df_old: pd.DataFrame,
                        join_col: str = "clean_name") -> pd.DataFrame:
    """
    Trend Score = % growth in review_count from old snapshot → new snapshot.

    Positive score = product gaining traction.
    Clipped at 0 (we don't penalise declining products here; that's a separate signal).

    Returns merged DataFrame with:
        review_growth_pct, price_change_pct, trend_score
    """
    merged = df_new.merge(
        df_old[[join_col, "review_count", "price"]],
        on=join_col,
        suffixes=("_new", "_old"),
        how="inner",
    )

    old_reviews = merged["review_count_old"].replace(0, 1)  # avoid division by zero
    old_price   = merged["price_old"].replace(0, 1)

    merged["review_growth_pct"] = (
        (merged["review_count_new"] - merged["review_count_old"]) / old_reviews * 100
    ).round(2)

    merged["price_change_pct"] = (
        (merged["price_new"] - merged["price_old"]) / old_price * 100
    ).round(2)

    merged["trend_score"] = merged["review_growth_pct"].clip(lower=0).round(4)

    return merged.sort_values("trend_score", ascending=False).reset_index(drop=True)


# ── Price ratio feature ───────────────────────────────────────────────────────

def add_price_ratio(df: pd.DataFrame) -> pd.DataFrame:
    """
    For each product, compute its price relative to the category average.
        price_ratio < 1  →  cheaper than average
        price_ratio > 1  →  more expensive than average
    """
    df = df.copy()
    category_avg = df.groupby("category")["price"].transform("mean")
    df["price_ratio"] = (df["price"] / category_avg.replace(0, 1)).round(3)
    return df


# ── Value score ───────────────────────────────────────────────────────────────

def compute_value_score(df: pd.DataFrame) -> pd.DataFrame:
    """
    Value Score = popularity_score / price_ratio

    High popularity + low relative price = great value.
    """
    df = df.copy()
    if "popularity_score" not in df.columns:
        df = compute_popularity_score(df)
    if "price_ratio" not in df.columns:
        df = add_price_ratio(df)

    df["value_score"] = (
        df["popularity_score"] / df["price_ratio"].replace(0, 1)
    ).round(4)

    return df


# ── Full feature pipeline ─────────────────────────────────────────────────────

def build_features(df: pd.DataFrame) -> pd.DataFrame:
    """Run all feature engineering steps on a cleaned DataFrame."""
    df = compute_popularity_score(df)
    df = add_price_ratio(df)
    df = compute_value_score(df)
    return df


# ── Quick test ────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import sys
    sys.path.insert(0, ".")
    from data_cleaner import clean_dataframe

    raw = pd.read_csv("../data/products.csv")
    cleaned = clean_dataframe(raw)
    featured = build_features(cleaned)

    print("\nTop 10 by Popularity Score:")
    print(featured.nlargest(10, "popularity_score")[
        ["product_name", "platform", "popularity_score", "price"]
    ].to_string(index=False))

    print("\nTop 10 by Value Score:")
    print(featured.nlargest(10, "value_score")[
        ["product_name", "platform", "value_score", "price"]
    ].to_string(index=False))
