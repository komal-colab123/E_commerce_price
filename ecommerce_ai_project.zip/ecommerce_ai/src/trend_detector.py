"""
Module: trend_detector.py
Purpose: Detect trending products using review growth velocity.
         Also supports simple ML-based ranking using Linear Regression.
"""

import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import MinMaxScaler


# ── Rule-based trend detection ────────────────────────────────────────────────

def detect_trending_rule_based(df: pd.DataFrame,
                                top_n: int = 20) -> pd.DataFrame:
    """
    Trending = high popularity_score + high review_count (proxy for velocity).

    When you only have one snapshot (no historical data), we use:
        - review_count  (absolute proxy for accumulated interest)
        - popularity_score (composite of rating + reviews)
        - high rating (social proof)

    Returns top_n products ranked by a composite trending metric.
    """
    df = df.copy()
    scaler = MinMaxScaler()

    features = df[["popularity_score", "review_count", "rating"]].copy()
    scaled   = scaler.fit_transform(features)

    # Weights: reviews contribute most (momentum signal), then popularity, then rating
    df["trending_score"] = (
        0.45 * scaled[:, 1] +   # review_count
        0.35 * scaled[:, 0] +   # popularity_score
        0.20 * scaled[:, 2]     # rating
    ).round(4)

    return (
        df.sort_values("trending_score", ascending=False)
          .head(top_n)
          .reset_index(drop=True)
    )


# ── ML-based ranking (Linear Regression as a ranker) ─────────────────────────

def train_popularity_ranker(df: pd.DataFrame):
    """
    Train a simple Linear Regression model to predict popularity_score
    from price, rating, and log_reviews.

    This is a beginner-friendly ML model that:
    - Is easy to explain (coefficients = importance)
    - Runs instantly, needs no GPU
    - Is interview-ready (you can discuss features, weights, MSE)

    Returns
    -------
    model      : Trained LinearRegression model
    feature_cols: List of feature column names
    """
    from sklearn.model_selection import train_test_split
    from sklearn.metrics import mean_squared_error, r2_score

    feature_cols = ["price", "rating", "log_reviews"]
    df = df.copy()
    df["log_reviews"] = np.log1p(df["review_count"])

    X = df[feature_cols].fillna(0)
    y = df["popularity_score"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    model = LinearRegression()
    model.fit(X_train, y_train)

    y_pred = model.predict(X_test)
    mse  = mean_squared_error(y_test, y_pred)
    r2   = r2_score(y_test, y_pred)

    print(f"\n── Linear Regression Ranker ──")
    print(f"   R² score : {r2:.3f}  (1.0 = perfect)")
    print(f"   MSE      : {mse:.5f}")
    print(f"   Coefficients:")
    for feat, coef in zip(feature_cols, model.coef_):
        print(f"     {feat:<15} {coef:+.4f}")
    print(f"   Intercept: {model.intercept_:.4f}")

    return model, feature_cols


def predict_popularity(model, feature_cols: list, df: pd.DataFrame) -> pd.DataFrame:
    """
    Use trained model to predict popularity scores for new products.
    """
    df = df.copy()
    df["log_reviews"] = np.log1p(df["review_count"])
    X = df[feature_cols].fillna(0)
    df["predicted_popularity"] = model.predict(X).clip(0, 1).round(4)
    return df


# ── Category-level trend summary ──────────────────────────────────────────────

def category_trend_summary(df: pd.DataFrame) -> pd.DataFrame:
    """Summarise trending signals by product category."""
    summary = (
        df.groupby("category")
          .agg(
              total_products  = ("product_name", "count"),
              avg_popularity  = ("popularity_score", "mean"),
              avg_rating      = ("rating", "mean"),
              total_reviews   = ("review_count", "sum"),
              avg_price       = ("price", "mean"),
          )
          .round(3)
          .sort_values("avg_popularity", ascending=False)
          .reset_index()
    )
    return summary


# ── Platform-level summary ────────────────────────────────────────────────────

def platform_summary(df: pd.DataFrame) -> pd.DataFrame:
    """Summarise key metrics by platform."""
    summary = (
        df.groupby("platform")
          .agg(
              total_products  = ("product_name", "count"),
              avg_price       = ("price", "mean"),
              avg_rating      = ("rating", "mean"),
              total_reviews   = ("review_count", "sum"),
              avg_popularity  = ("popularity_score", "mean"),
          )
          .round(3)
          .sort_values("avg_popularity", ascending=False)
          .reset_index()
    )
    return summary


# ── Quick test ────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import sys
    sys.path.insert(0, ".")
    from data_cleaner import clean_dataframe
    from feature_engineering import build_features

    raw = pd.read_csv("../data/products.csv")
    df  = build_features(clean_dataframe(raw))

    print("\nTop 10 Trending Products:")
    trending = detect_trending_rule_based(df, top_n=10)
    print(trending[["product_name", "platform", "trending_score",
                     "popularity_score", "review_count"]].to_string(index=False))

    print("\nCategory Trend Summary:")
    print(category_trend_summary(df).to_string(index=False))

    print("\nPlatform Summary:")
    print(platform_summary(df).to_string(index=False))

    # ML model
    model, feat_cols = train_popularity_ranker(df)
    df = predict_popularity(model, feat_cols, df)
    print("\nML predicted vs actual (top 5):")
    print(df.nlargest(5, "predicted_popularity")[
        ["product_name", "popularity_score", "predicted_popularity"]
    ].to_string(index=False))
