"""
Module: data_cleaner.py
Purpose: Clean and normalise raw e-commerce product data.
"""

import re
import pandas as pd


# ── Brand extraction ──────────────────────────────────────────────────────────

KNOWN_BRANDS = [
    "boat", "sony", "jbl", "apple", "samsung", "noise", "fire-boltt",
    "redmi", "oneplus", "iqoo", "levi's", "nike", "himalaya", "lakme",
    "prestige", "instant pot", "philips", "bosch", "lg", "realme", "oppo",
    "vivo", "mi", "poco", "asus", "acer", "hp", "dell", "lenovo",
]


def extract_brand(name: str) -> str:
    """Extract brand from product name using a known-brands list."""
    name_lower = name.lower()
    for brand in KNOWN_BRANDS:
        if brand in name_lower:
            return brand.title()
    # Fallback: first word
    words = name_lower.split()
    return words[0].title() if words else "Unknown"


# ── Category extraction ───────────────────────────────────────────────────────

CATEGORY_KEYWORDS = {
    "Audio":      ["headphone", "earphone", "earbud", "speaker", "airpods", "buds", "rockerz", "airdopes", "tune"],
    "Wearables":  ["smartwatch", "smart watch", "fitness watch", "band", "watch"],
    "Phones":     ["mobile", "phone", "smartphone", "5g phone", "4g phone"],
    "Computers":  ["laptop", "tablet", "ipad", "notebook"],
    "Fashion":    ["shirt", "dress", "jeans", "shoes", "sneakers", "top", "kurta", "saree", "t-shirt"],
    "Beauty":     ["face wash", "lipstick", "cream", "serum", "shampoo", "conditioner", "moisturiser"],
    "Kitchen":    ["mixer", "grinder", "pressure cooker", "cooker", "blender", "juicer", "toaster"],
}


def extract_category(name: str) -> str:
    """Map product name to a broad category using keyword matching."""
    name_lower = name.lower()
    for category, keywords in CATEGORY_KEYWORDS.items():
        for kw in keywords:
            if kw in name_lower:
                return category
    return "General"


# ── Name cleaning ─────────────────────────────────────────────────────────────

def clean_name(name: str) -> str:
    """
    Normalise product name for comparison:
    - Lowercase
    - Remove special characters except spaces
    - Collapse multiple spaces
    """
    name = str(name).lower()
    name = re.sub(r"[^a-z0-9 ]", " ", name)
    name = re.sub(r"\s+", " ", name).strip()
    return name


# ── Price normalisation ───────────────────────────────────────────────────────

def clean_price(price) -> float:
    """Convert price to float, stripping currency symbols / commas."""
    price_str = str(price).replace(",", "").replace("₹", "").replace("$", "").strip()
    try:
        return float(price_str)
    except ValueError:
        return 0.0


# ── Main cleaner ──────────────────────────────────────────────────────────────

def clean_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    """
    Full cleaning pipeline for raw product DataFrame.

    Input columns expected:
        product_name, price, rating, review_count, platform

    New columns added:
        clean_name, brand, category
    """
    df = df.copy()

    # Remove rows with no product name
    df = df.dropna(subset=["product_name"])
    df = df[df["product_name"].str.strip() != ""]

    # Normalise numeric fields
    df["price"]        = df["price"].apply(clean_price)
    df["rating"]       = pd.to_numeric(df["rating"], errors="coerce").fillna(0.0).clip(0, 5)
    df["review_count"] = pd.to_numeric(df["review_count"], errors="coerce").fillna(0).astype(int)

    # Text cleaning
    df["clean_name"] = df["product_name"].apply(clean_name)
    df["brand"]      = df["product_name"].apply(extract_brand)
    df["category"]   = df["product_name"].apply(extract_category)

    # Standardise platform names
    platform_map = {
        "amazon":   "Amazon",
        "flipkart": "Flipkart",
        "myntra":   "Myntra",
        "meesho":   "Meesho",
    }
    df["platform"] = df["platform"].str.strip().str.lower().map(platform_map).fillna(df["platform"])

    df = df.reset_index(drop=True)
    return df


# ── Quick test ────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    sample = pd.DataFrame([
        {"product_name": "boAt Rockerz 450 Bluetooth Headphone",
         "price": "1,499", "rating": 4.1, "review_count": "85,000", "platform": "amazon"},
        {"product_name": "Sony WH-1000XM4 Noise Cancelling Headphones",
         "price": 24990, "rating": 4.6, "review_count": 32000, "platform": "Flipkart"},
    ])
    cleaned = clean_dataframe(sample)
    print(cleaned[["product_name", "clean_name", "brand", "category", "price", "platform"]])
