# models/trend_model.py
# ─────────────────────────────────────────────────────────
# Optional: ML-based product category classifier.
#
# Uses Multinomial Naive Bayes on TF-IDF vectors of product names.
# Trains on your existing labelled data (after cleaner.py runs).
#
# Beginner note: Naive Bayes is the best starting ML model for
# text classification — it's fast, interpretable, and works well
# on small datasets.
# ─────────────────────────────────────────────────────────

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score
import pickle


MODEL_PATH = os.path.join(os.path.dirname(__file__), "category_classifier.pkl")


# ── Training ──────────────────────────────────────────────

def train_category_classifier(df: pd.DataFrame,
                               save: bool = True) -> Pipeline:
    """
    Train a Naive Bayes classifier to predict product category
    from the cleaned product name.

    Args:
        df:   Cleaned DataFrame with 'clean_name' and 'category' columns.
        save: Whether to save the model to disk.

    Returns:
        Trained sklearn Pipeline.
    """
    # Filter out 'General' — too noisy to train on
    df_train = df[df["category"] != "General"].copy()

    if len(df_train) < 10:
        print("[Model] Not enough labelled data to train. Need ≥10 non-General rows.")
        return None

    X = df_train["clean_name"]
    y = df_train["category"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y if len(y.unique()) > 1 else None
    )

    # Pipeline: TF-IDF vectoriser → Naive Bayes
    pipeline = Pipeline([
        ("tfidf", TfidfVectorizer(ngram_range=(1, 2), sublinear_tf=True)),
        ("clf",   MultinomialNB(alpha=0.5)),  # alpha = Laplace smoothing
    ])

    pipeline.fit(X_train, y_train)

    # Evaluate
    if len(X_test) > 0:
        y_pred = pipeline.predict(X_test)
        acc = accuracy_score(y_test, y_pred)
        print(f"[Model] Category classifier accuracy: {acc:.2%}")
        print(classification_report(y_test, y_pred, zero_division=0))

    if save:
        with open(MODEL_PATH, "wb") as f:
            pickle.dump(pipeline, f)
        print(f"[Model] Saved to {MODEL_PATH}")

    return pipeline


# ── Inference ─────────────────────────────────────────────

def load_classifier() -> Pipeline:
    """Load a previously saved classifier."""
    if not os.path.exists(MODEL_PATH):
        raise FileNotFoundError(
            f"No saved model at {MODEL_PATH}. Run train_category_classifier() first."
        )
    with open(MODEL_PATH, "rb") as f:
        return pickle.load(f)


def predict_category(product_names: list, pipeline: Pipeline = None) -> list:
    """
    Predict categories for a list of product name strings.

    Args:
        product_names: list of raw or cleaned product name strings
        pipeline:      trained Pipeline (loads from disk if None)

    Returns:
        list of predicted category strings
    """
    if pipeline is None:
        pipeline = load_classifier()

    # Clean names before prediction
    from utils.cleaner import clean_name
    cleaned = [clean_name(n) for n in product_names]
    return pipeline.predict(cleaned).tolist()


# ── Trend Label Classifier (rule-enhanced) ────────────────

def classify_trend(review_growth_pct: float,
                   popularity_score: float) -> str:
    """
    Simple rule-based trend classification.
    Combine with ML scores for a hybrid approach.

    Returns: "Viral", "Hot", "Rising", "Stable", "Declining"
    """
    if review_growth_pct >= 50 and popularity_score >= 0.7:
        return "Viral"
    if review_growth_pct >= 25:
        return "Hot"
    if review_growth_pct >= 10:
        return "Rising"
    if review_growth_pct >= 0:
        return "Stable"
    return "Declining"


# ── Quick Test ────────────────────────────────────────────
if __name__ == "__main__":
    import sys
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

    # Load real data to train on
    from utils.cleaner import clean_dataframe

    data_path = os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        "data", "sample_products.csv"
    )
    df = clean_dataframe(pd.read_csv(data_path))

    print(f"Category distribution:\n{df['category'].value_counts()}\n")

    pipeline = train_category_classifier(df, save=False)

    if pipeline:
        test_names = [
            "Redmi Note 13 5G Smartphone",
            "Nike Air Force 1 Running Shoes",
            "Lakme Matte Lipstick Red",
            "HP Pavilion Gaming Laptop i7",
        ]
        predictions = predict_category(test_names, pipeline)
        for name, pred in zip(test_names, predictions):
            print(f"  {name:<45} → {pred}")
