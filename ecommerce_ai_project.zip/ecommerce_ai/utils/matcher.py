# utils/matcher.py
# ─────────────────────────────────────────────────────────
# Cross-platform product matching using TF-IDF + cosine similarity.
#
# Same product listed on Amazon and Flipkart will have slightly
# different names. TF-IDF converts names to vectors; cosine
# similarity finds the closest pair across platforms.
# ─────────────────────────────────────────────────────────

import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import MATCH_THRESHOLD, TFIDF_NGRAM_RANGE


def match_products(df: pd.DataFrame,
                   threshold: float = MATCH_THRESHOLD) -> pd.DataFrame:
    """
    Find the same product listed across different platforms.

    Algorithm:
        1. Vectorise all product names using TF-IDF (unigrams + bigrams).
        2. Compute an n×n cosine similarity matrix.
        3. For every pair (i, j) where:
               - platforms are different, AND
               - similarity >= threshold
           record as a match.

    Returns a DataFrame with columns:
        product_a, platform_a, price_a,
        product_b, platform_b, price_b,
        similarity, price_diff, cheaper_on, saving_pct
    """
    if df.empty:
        return pd.DataFrame()

    # ── Build TF-IDF matrix ──
    vectorizer = TfidfVectorizer(
        ngram_range=TFIDF_NGRAM_RANGE,
        sublinear_tf=True,        # dampens very frequent terms
        min_df=1,
    )
    tfidf_matrix = vectorizer.fit_transform(df["match_name"])

    # ── Cosine similarity (n×n) ──
    sim_matrix = cosine_similarity(tfidf_matrix)

    matches = []
    n = len(df)

    for i in range(n):
        for j in range(i + 1, n):
            if df.iloc[i]["platform"] == df.iloc[j]["platform"]:
                continue  # only cross-platform pairs

            score = sim_matrix[i][j]
            if score < threshold:
                continue

            price_a = df.iloc[i]["price"]
            price_b = df.iloc[j]["price"]
            price_diff = abs(price_a - price_b)

            cheaper_idx  = i if price_a <= price_b else j
            expensive_idx = j if price_a <= price_b else i
            saving_pct = (
                price_diff / max(df.iloc[expensive_idx]["price"], 1) * 100
            )

            matches.append({
                "product_a":    df.iloc[i]["product_name"],
                "platform_a":   df.iloc[i]["platform"],
                "price_a":      price_a,
                "rating_a":     df.iloc[i]["rating"],
                "product_b":    df.iloc[j]["product_name"],
                "platform_b":   df.iloc[j]["platform"],
                "price_b":      price_b,
                "rating_b":     df.iloc[j]["rating"],
                "similarity":   round(score, 3),
                "price_diff":   round(price_diff, 2),
                "cheaper_on":   df.iloc[cheaper_idx]["platform"],
                "saving_pct":   round(saving_pct, 2),
                "category":     df.iloc[i].get("category", "General"),
                "brand":        df.iloc[i].get("brand", "Unknown"),
            })

    result = pd.DataFrame(matches)

    if not result.empty:
        result = result.sort_values("similarity", ascending=False)

    print(f"[Matcher] Found {len(result)} cross-platform matches "
          f"(threshold={threshold}).")
    return result


def best_deal(matches_df: pd.DataFrame) -> pd.DataFrame:
    """
    From the matches, return only the best deal per product group
    (the pair with the largest saving_pct).
    """
    if matches_df.empty:
        return pd.DataFrame()

    # Group by brand + category as a proxy for product group
    idx = matches_df.groupby(["brand", "category"])["saving_pct"].idxmax()
    return matches_df.loc[idx].reset_index(drop=True)


# ── Quick Test ────────────────────────────────────────────
if __name__ == "__main__":
    test_df = pd.DataFrame({
        "product_name": [
            "boAt Rockerz 450 Bluetooth Headphone",
            "boAt Rockerz 450 Wireless Headphones",
            "Sony WH-1000XM5 Noise Cancelling Headphones",
            "Sony WH-1000XM5 Wireless Headphone",
            "Nike Air Max 270 Running Shoes",
            "Adidas Ultraboost 22 Running Shoes",
        ],
        "match_name": [
            "boat rockerz 450 bluetooth headphone",
            "boat rockerz 450 wireless headphones",
            "sony wh1000xm5 noise cancelling headphones",
            "sony wh1000xm5 wireless headphone",
            "nike air max 270 running shoes",
            "adidas ultraboost 22 running shoes",
        ],
        "price":    [1499, 1399, 29990, 28999, 8995, 12999],
        "rating":   [4.1, 4.0, 4.6, 4.5, 4.5, 4.6],
        "platform": ["Amazon", "Flipkart", "Amazon", "Flipkart", "Amazon", "Amazon"],
        "brand":    ["Boat", "Boat", "Sony", "Sony", "Nike", "Adidas"],
        "category": ["Audio", "Audio", "Audio", "Audio", "Fashion", "Fashion"],
    })

    matches = match_products(test_df, threshold=0.70)
    print(matches[["product_a", "platform_a", "price_a",
                   "product_b", "platform_b", "price_b",
                   "similarity", "cheaper_on", "saving_pct"]])
