# utils/reporter.py
# ─────────────────────────────────────────────────────────
# Generates all output files and prints console summaries.
# ─────────────────────────────────────────────────────────

import os
import json
import pandas as pd
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import (OUTPUT_DIR, TRENDING_OUT, MATCHES_OUT,
                    REPORT_OUT, TOP_N_PRODUCTS)


def _ensure_output_dir():
    os.makedirs(OUTPUT_DIR, exist_ok=True)


# ── Trending Products Report ──────────────────────────────

def save_trending_report(df: pd.DataFrame, top_n: int = TOP_N_PRODUCTS) -> str:
    """Save top products ranked by popularity_score."""
    _ensure_output_dir()

    cols = [c for c in [
        "product_name", "brand", "category", "platform",
        "price", "rating", "review_count",
        "popularity_score", "popularity_tier",
    ] if c in df.columns]

    top = df.nlargest(top_n, "popularity_score")[cols]
    top.insert(0, "rank", range(1, len(top) + 1))
    top.to_csv(TRENDING_OUT, index=False)
    print(f"[Reporter] Trending report → {TRENDING_OUT}")
    return TRENDING_OUT


# ── Price Comparison Report ───────────────────────────────

def save_price_comparison(matches_df: pd.DataFrame) -> str:
    """Save cross-platform price comparison."""
    _ensure_output_dir()

    cols = [c for c in [
        "brand", "category",
        "product_a", "platform_a", "price_a", "rating_a",
        "product_b", "platform_b", "price_b", "rating_b",
        "similarity", "price_diff", "cheaper_on", "saving_pct",
    ] if c in matches_df.columns]

    matches_df[cols].to_csv(MATCHES_OUT, index=False)
    print(f"[Reporter] Price comparison → {MATCHES_OUT}")
    return MATCHES_OUT


# ── Full Master Report ────────────────────────────────────

def save_full_report(df: pd.DataFrame) -> str:
    """Save all enriched product data to one master CSV."""
    _ensure_output_dir()

    df.to_csv(REPORT_OUT, index=False)
    print(f"[Reporter] Full report → {REPORT_OUT}")
    return REPORT_OUT


# ── Console Summary ───────────────────────────────────────

def print_summary(df: pd.DataFrame, matches_df: pd.DataFrame,
                  trend_df: pd.DataFrame = None):
    """Pretty-print a summary to the console."""
    sep = "─" * 60

    print(f"\n{sep}")
    print("  E-COMMERCE AI INTELLIGENCE REPORT")
    print(sep)

    # Platform summary
    print("\n📦 Products per Platform:")
    plat = df.groupby("platform").agg(
        products=("product_name", "count"),
        avg_price=("price", "mean"),
        avg_rating=("rating", "mean"),
    ).round(2)
    print(plat.to_string())

    # Category summary
    print("\n🏷  Products per Category:")
    cat = df.groupby("category")["product_name"].count().sort_values(ascending=False)
    print(cat.to_string())

    # Top 5 popular products
    print("\n🏆 Top 5 Products by Popularity Score:")
    top5 = df.nlargest(5, "popularity_score")[
        ["product_name", "platform", "price", "rating",
         "review_count", "popularity_score", "popularity_tier"]
    ]
    for _, row in top5.iterrows():
        print(f"  [{row['popularity_tier']:6}] {row['product_name'][:45]:<45} "
              f"| ₹{row['price']:>8,.0f} | ⭐{row['rating']} "
              f"| Score: {row['popularity_score']:.3f}")

    # Top 5 trending (if available)
    if trend_df is not None and not trend_df.empty and "trend_score" in trend_df.columns:
        print("\n🔥 Top 5 Trending Products (Fastest Growing Reviews):")
        t5 = trend_df.nlargest(5, "trend_score")
        for _, row in t5.iterrows():
            print(f"  [{row.get('trend_label','?'):8}] {row['product_name'][:45]:<45} "
                  f"| Growth: +{row['trend_score']:.1f}%")

    # Best price deals
    if not matches_df.empty:
        print("\n💰 Top 5 Price Deals (Same Product, Cheaper Elsewhere):")
        best = matches_df.nlargest(5, "saving_pct")
        for _, row in best.iterrows():
            print(f"  {row['product_a'][:40]:<40} | "
                  f"₹{row['price_a']:>8,.0f} ({row['platform_a']}) vs "
                  f"₹{row['price_b']:>8,.0f} ({row['platform_b']}) | "
                  f"Save {row['saving_pct']:.1f}% on {row['cheaper_on']}")

    print(f"\n{sep}\n")


# ── JSON Export (for API responses) ──────────────────────

def to_json_report(df: pd.DataFrame,
                   matches_df: pd.DataFrame,
                   top_n: int = TOP_N_PRODUCTS) -> dict:
    """
    Build a JSON-serialisable dict for the Flask API.
    """
    trending_cols = [c for c in [
        "product_name", "brand", "category", "platform",
        "price", "rating", "review_count",
        "popularity_score", "popularity_tier",
    ] if c in df.columns]

    top = df.nlargest(top_n, "popularity_score")[trending_cols]
    top.insert(0, "rank", range(1, len(top) + 1))

    platform_summary = (
        df.groupby("platform")
        .agg(products=("product_name", "count"),
             avg_price=("price", "mean"),
             avg_rating=("rating", "mean"))
        .round(2)
        .reset_index()
        .to_dict("records")
    )

    category_summary = (
        df.groupby("category")["product_name"]
        .count()
        .sort_values(ascending=False)
        .reset_index()
        .rename(columns={"product_name": "count"})
        .to_dict("records")
    )

    return {
        "status": "success",
        "total_products": len(df),
        "trending": top.to_dict("records"),
        "price_comparison": matches_df.to_dict("records") if not matches_df.empty else [],
        "platform_summary": platform_summary,
        "category_summary": category_summary,
    }
