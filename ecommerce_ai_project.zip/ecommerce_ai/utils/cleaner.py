# utils/cleaner.py
# ─────────────────────────────────────────────────────────
# Cleans raw product data: normalises names, extracts brand
# and category, validates numeric columns.
# ─────────────────────────────────────────────────────────

import re
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pandas as pd
from config import CATEGORY_KEYWORDS, PLATFORMS


# ── Name Cleaning ─────────────────────────────────────────

def clean_name(name: str) -> str:
    """
    Lowercase, strip special characters, collapse whitespace.

    Example:
        "boAt Rockerz 450 Bluetooth Headphone!!" -> "boat rockerz 450 bluetooth headphone"
    """
    if not isinstance(name, str):
        return ""
    name = name.lower()
    name = re.sub(r'[^a-z0-9 ]', ' ', name)   # keep only alphanumeric + space
    name = re.sub(r'\s+', ' ', name).strip()   # collapse multiple spaces
    return name


def remove_stopwords(name: str) -> str:
    """
    Remove common filler words that don't help with matching.
    Keeps brand names, model numbers, and key descriptors.
    """
    stopwords = {
        'with', 'and', 'for', 'the', 'in', 'on', 'of', 'to', 'a',
        'an', 'by', 'is', 'it', 'at', 'be', 'as', 'or', 'from',
    }
    tokens = name.split()
    return ' '.join(t for t in tokens if t not in stopwords)


# ── Brand Extraction ──────────────────────────────────────

# Known brand names to look for (expandable)
KNOWN_BRANDS = [
    "boat", "sony", "samsung", "apple", "redmi", "realme", "oneplus",
    "nokia", "motorola", "oppo", "vivo", "asus", "hp", "dell", "lenovo",
    "noise", "fire-boltt", "firebolt", "amazfit", "fastrack",
    "nike", "adidas", "puma", "reebok", "woodland", "bata",
    "levi", "levis", "hm", "zara", "allen", "wildcraft",
    "lakme", "mamaearth", "himalaya", "biotique", "wow", "philips",
    "prestige", "bajaj", "havells", "usha", "kent", "eureka",
]


def extract_brand(clean_name_str: str) -> str:
    """
    Try known brands first; fall back to first token.

    Why: First token heuristic breaks for products like
    "Mi 11 Lite" (brand = Mi, not first token problem here,
    but "New Sony..." would give "New" as brand).
    """
    for brand in KNOWN_BRANDS:
        # Match whole word only
        if re.search(r'\b' + re.escape(brand) + r'\b', clean_name_str):
            return brand.title()

    # Fallback: first word
    tokens = clean_name_str.split()
    return tokens[0].title() if tokens else "Unknown"


# ── Category Extraction ───────────────────────────────────

def extract_category(name: str) -> str:
    """
    Map product to a category using keyword matching.
    Uses the CATEGORY_KEYWORDS dict from config.py.
    """
    name_lower = name.lower()
    for category, keywords in CATEGORY_KEYWORDS.items():
        for kw in keywords:
            if kw in name_lower:
                return category
    return "General"


# ── Platform Validation ───────────────────────────────────

def validate_platform(platform: str) -> str:
    """Standardise platform names (handle typos / case issues)."""
    if not isinstance(platform, str):
        return "Unknown"
    platform = platform.strip().title()
    return platform if platform in PLATFORMS else "Unknown"


# ── Main Cleaning Function ────────────────────────────────

def clean_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    """
    Full cleaning pipeline. Call this on your raw scraped DataFrame.

    Input columns expected:
        product_name, price, rating, review_count, platform

    Output adds:
        clean_name, match_name, brand, category
    """
    df = df.copy()

    # ── Validate required columns ──
    required = ["product_name", "price", "rating", "review_count", "platform"]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"Missing columns: {missing}")

    # ── Numeric columns ──
    df["price"]        = pd.to_numeric(df["price"],        errors="coerce").fillna(0)
    df["rating"]       = pd.to_numeric(df["rating"],       errors="coerce").fillna(0)
    df["review_count"] = pd.to_numeric(df["review_count"], errors="coerce").fillna(0).astype(int)

    # ── Clip rating to valid range ──
    df["rating"] = df["rating"].clip(0, 5)

    # ── Drop rows with no product name ──
    df = df.dropna(subset=["product_name"])
    df = df[df["product_name"].str.strip() != ""]

    # ── Text cleaning ──
    df["clean_name"]  = df["product_name"].apply(clean_name)
    df["match_name"]  = df["clean_name"].apply(remove_stopwords)  # used in TF-IDF
    df["brand"]       = df["clean_name"].apply(extract_brand)
    df["category"]    = df["product_name"].apply(extract_category)
    df["platform"]    = df["platform"].apply(validate_platform)

    # ── Reset index ──
    df = df.reset_index(drop=True)

    print(f"[Cleaner] Processed {len(df)} products across "
          f"{df['platform'].nunique()} platforms, "
          f"{df['category'].nunique()} categories.")
    return df


# ── Quick Test ────────────────────────────────────────────
if __name__ == "__main__":
    test_data = {
        "product_name": [
            "boAt Rockerz 450 Bluetooth Headphone!!",
            "Sony WH-1000XM5 Noise Cancelling Headphones",
            "Levi's Men's 511 Slim Jeans",
        ],
        "price": [1499, 29990, "2,499"],
        "rating": [4.1, 4.6, 4.4],
        "review_count": [85000, 12000, 23000],
        "platform": ["Amazon", "flipkart", "Myntra"],
    }
    result = clean_dataframe(pd.DataFrame(test_data))
    print(result[["product_name", "clean_name", "brand", "category", "platform"]])
