# utils/scorer.py
# ─────────────────────────────────────────────────────────
# Computes:
#   - Popularity Score  (rating + log review count)
#   - Trend Score       (review growth between two scrapes)
#   - Price stats       (min, max, average per product group)
# ─────────────────────────────────────────────────────────

import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import WEIGHT_RATING, WEIGHT_REVIEWS, TREND_TOP_N


# ── Popularity Score ──────────────────────────────────────

def compute_popularity(df: pd.DataFrame) -> pd.DataFrame:
    """
    Adds 'popularity_score' column (0.0 – 1.0).

    Formula:
        popularity_score = W_rating  × norm(rating)
                         + W_reviews × norm(log(review_count + 1))

    Why log on reviews?
        A product with 500k reviews shouldn't dwarf a solid product
        with 20k reviews. log compresses the scale so review quality
        matters more than raw volume.
    """
    df = df.copy()

    # log(1 + x) handles zero review_count gracefully
    df["log_reviews"] = np.log1p(df["review_count"])

    scaler = MinMaxScaler()
    df[["norm_rating", "norm_log_reviews"]] = scaler.fit_transform(
        df[["rating", "log_reviews"]]
    )

    df["popularity_score"] = (
        WEIGHT_RATING  * df["norm_rating"] +
        WEIGHT_REVIEWS * df["norm_log_reviews"]
    ).round(4)

    # Popularity tier label (makes reports more readable)
    df["popularity_tier"] = pd.cut(
        df["popularity_score"],
        bins=[0, 0.4, 0.6, 0.75, 0.9, 1.01],
        labels=["Low", "Medium", "Good", "High", "Top"],
        right=False,
    )

    print(f"[Scorer] Popularity computed. "
          f"Top scorer: {df.nlargest(1, 'popularity_score')['product_name'].values[0]}")
    return df


# ── Trend Score ───────────────────────────────────────────

def compute_trend(df_current: pd.DataFrame,
                  df_baseline: pd.DataFrame) -> pd.DataFrame:
    """
    Computes review growth (%) and price change (%) between two scrapes.

    Requires 'clean_name' and 'platform' in both DataFrames.
    Returns only products present in both scrapes.

    Columns added:
        review_growth_pct  – positive = growing, negative = declining
        price_change_pct   – positive = more expensive now
        trend_score        – clipped review_growth_pct (negatives → 0)
        trend_label        – "Hot", "Rising", "Stable", "Declining"
    """
    merge_keys = ["clean_name", "platform"]

    merged = df_current.merge(
        df_baseline[merge_keys + ["review_count", "price"]],
        on=merge_keys,
        suffixes=("_now", "_old"),
    )

    # Avoid division by zero
    old_reviews = merged["review_count_old"].replace(0, 1)
    old_price   = merged["price_old"].replace(0, 1)

    merged["review_growth_pct"] = (
        (merged["review_count_now"] - merged["review_count_old"]) / old_reviews * 100
    ).round(2)

    merged["price_change_pct"] = (
        (merged["price_now"] - merged["price_old"]) / old_price * 100
    ).round(2)

    # trend_score ignores declining products (clip negatives to 0)
    merged["trend_score"] = merged["review_growth_pct"].clip(lower=0).round(2)

    # Human-readable trend label
    def label_trend(pct):
        if pct >= 30:   return "Hot"
        if pct >= 10:   return "Rising"
        if pct >= 0:    return "Stable"
        return "Declining"

    merged["trend_label"] = merged["review_growth_pct"].apply(label_trend)

    result = merged.sort_values("trend_score", ascending=False)

    hot_count = (result["trend_label"] == "Hot").sum()
    print(f"[Scorer] Trend computed for {len(result)} products. "
          f"{hot_count} labelled 'Hot'.")
    return result


# ── Price Statistics per Category / Platform ──────────────

def compute_price_stats(df: pd.DataFrame) -> pd.DataFrame:
    """
    Returns a summary of price ranges per category and platform.
    Useful for the price comparison report.
    """
    stats = (
        df.groupby(["category", "platform"])
        .agg(
            min_price  =("price", "min"),
            max_price  =("price", "max"),
            avg_price  =("price", "mean"),
            product_count=("product_name", "count"),
        )
        .round(2)
        .reset_index()
    )
    return stats


# ── Quick Test ────────────────────────────────────────────
if __name__ == "__main__":
    import pandas as pd

    sample = pd.DataFrame({
        "product_name": ["Product A", "Product B", "Product C"],
        "clean_name":   ["product a", "product b", "product c"],
        "platform":     ["Amazon", "Flipkart", "Myntra"],
        "price":        [1000, 2000, 500],
        "rating":       [4.5, 3.8, 4.2],
        "review_count": [50000, 5000, 25000],
    })

    scored = compute_popularity(sample)
    print(scored[["product_name", "rating", "review_count",
                  "popularity_score", "popularity_tier"]])
